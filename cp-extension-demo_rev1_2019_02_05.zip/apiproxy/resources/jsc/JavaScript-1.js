 var first = context.getVariable("request.queryparam.a");
 var second = context.getVariable("request.queryparam.b");
 var result = parseInt(first) + parseInt(second);
 context.setVariable("request.queryparam.c", result);