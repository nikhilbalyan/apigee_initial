 print(context.getVariable("getURIParams.accountId"));
 print(context.getVariable("getURIParams.transactionId"));
 print(context.getVariable("getURIParams.cityName"));