var http = require('http');
var ipAddress = "";
var options = {host: "api.ipify.org", path: "/"};

var callback = function(response) {
    response.on("data", function(data) {
       ipAddress = data.toString();
       console.log("IP Address: " + ipAddress);
    });
}

http.request(options, callback).end();

var server = http.createServer(function(request, response) {
   response.setHeader("X-Node-Content-IP", ipAddress);
   response.end(ipAddress.split(".").reverse().join().replace(/,/g, '.'));
});

server.listen(9000, function(){
    
});